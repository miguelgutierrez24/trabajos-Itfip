<?php

$nombre = $_POST["nombre"];
$documento = $_POST["docu"];
$edad = $_POST["edad"];
if($edad >= 18)
{
    //echo $edad;
    //Si entra aca es por que es mayor de edad
    echo "eres mayor de edad <br>";
}else{
    echo "eres menor de edad<br>";
//Si entra aca es menor de edad
}
echo $nombre." - ".$documento

?>