<?php
$valor = $_POST["valor"];
$edad = $_POST["edad"];
$des = $venta*0.2;
$total = $venta-$des;
if($edad<=0){
    die("edad no valida");
}
if($edad>60)
{
echo "Te damos un descuento del 20%: <br> ".$des;
}
else //es menor de edad
{
    echo "la venta es de: <br>".$venta;
}

?>