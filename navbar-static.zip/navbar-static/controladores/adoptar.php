<?php

$nombre=$_POST["nombre"];
$nombre=$_POST["raza"];
$edad=$_POST["edad"];
 if($edad>=18)
{
echo "adoptaste el perro";
}else{
echo "NO PUEDES ADOPTAR, TRAE UN ADULTO RESPONSABLE";
}



?>