<?php

$nombre = $_POST["nombre"];
$nombre2 = $_POST["raza"];  
    echo $nombre. "-" .$nombre2;

?>