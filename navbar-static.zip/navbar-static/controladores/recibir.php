<?php

$cantidad=$_POST["cantidad"];
 if($cantidad>0)
{
echo "recibiste mascotas";
}else{
echo "NO PUEDES HACER ESO";
}



?>